# NoomSmartKeyboard

keyboard control game on python 

## Installation

Install my-project is

```bash
  pip install NoomSmartKeyboard 
```

## Use Code

Example

```bash
from NoomSmartKeyboard import press_key, release_key

# Now you can use these functions
press_key('n')  # Simulates pressing the 'n' key.
release_key('n')  # Simulates releasing the 'n' key.
press_key('o')  # Simulates pressing the 'n' key.
release_key('o')  # Simulates releasing the 'n' key.
press_key('o')  # Simulates pressing the 'n' key.
release_key('o')  # Simulates releasing the 'n' key.
press_key('m')  # Simulates pressing the 'n' key.
release_key('m')  # Simulates releasing the 'n' key.

#Output // noom


```
# Enjoy!!!
###  facebook : หนุ่ม ภูมิมินทร์